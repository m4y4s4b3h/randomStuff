
var __phone_order__ = function($) {
  $('#csr_header').draggable({handle: '#csr_dragger'});
}(jQuery);
