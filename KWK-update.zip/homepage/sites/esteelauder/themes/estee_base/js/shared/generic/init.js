
var $ = jQuery; var generic = generic || {}; var site = site || {}; var prodcat = prodcat || {};