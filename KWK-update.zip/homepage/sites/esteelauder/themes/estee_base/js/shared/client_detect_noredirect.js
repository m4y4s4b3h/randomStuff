
var site = site || {}; site.doMobileRedirect = false;
